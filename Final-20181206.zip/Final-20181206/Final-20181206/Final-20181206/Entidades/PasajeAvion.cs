﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public enum Servicio
    {
        Comun,
        SemiCama,
        Ejecutivo
    }
    public class PasajeAvion : Pasaje
    {

        private int cantidadDeEscalas;
        public int CantidadDeEscalas { get => cantidadDeEscalas; set => cantidadDeEscalas = value; }
        public PasajeAvion()
        {

        }
        public PasajeAvion(string origen, string destino, Pasajero pasajero, float precio, DateTime fecha, int cantidadEscalas)
        {
            this.CantidadDeEscalas = cantidadEscalas;
        }
        public override float PrecioFinal
            {
                get
            {
                float precioFinal = Precio;
                if(CantidadDeEscalas==1)
                {
                    precioFinal = precioFinal * 0.1f;
                    precioFinal = Precio - precioFinal;
                }
                else
                {
                    if(CantidadDeEscalas==2)
                    {
                        precioFinal = precioFinal * 0.2f;
                        precioFinal = Precio - precioFinal;
                    }
                    else
                    {
                        if(CantidadDeEscalas>2)
                        {
                            precioFinal = precioFinal * 0.3f;
                            precioFinal = Precio - precioFinal;
                        }
                    }
                }
                return precioFinal;

            }
            set
            {
                this.Precio = value;
            }
            }
        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendFormat("Cantidad de escalas: {0}\n", this.CantidadDeEscalas);
            sb.AppendFormat("Precio Total:{0}\n", this.PrecioFinal);
            return sb.ToString();
        }


    }
}
