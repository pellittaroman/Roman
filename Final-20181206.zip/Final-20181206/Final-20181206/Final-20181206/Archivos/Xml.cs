﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Archivos
{
    public class Xml<T>:IArchivos<T>
    {
       public T Leer(string origen)
        {
            T aux;
            XmlSerializer xml = new XmlSerializer(typeof(T));
            XmlTextReader reader = null;
            try
            {
                reader = new XmlTextReader(origen);
                aux=(T)xml.Deserialize(reader);
            }
            catch (Exception a)
            {

                throw a;
            }
            finally
            {
                reader.Close();
            }
            return aux;
            
        }
        public void Guardar(string origen, T datos)
        {
            XmlSerializer xml = new XmlSerializer(typeof(T));
            XmlTextWriter writer = null;
            try
            {
                writer = new XmlTextWriter(origen, null);
                xml.Serialize(writer, datos);
            }
            catch (Exception a)
            {

                throw a;
            }
            finally
            {
                writer.Close();
            }
        }
    }
}
