using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using Entidades;

namespace Archivos
{
    public class Texto:IArchivo<Queue<Patente>>
    {
      public void Guardar(string archivo,Queue<Patente> datos)
      {
      StreamWriter writer=null;
      try
      {
        writer = new StreamWriter(archivo);
        Patente aux=new Patente();
        while(datos.Count!=0)
        {
          aux = datos.Dequeue();
          writer.WriteLine(aux.CodigoPatente);
          
        }
       
      }
      catch (Exception a)
      {

        throw a;
      }
      finally
      {
        writer.Close();
      }
      

      

    }
      public void Leer(string archivo, out Queue<Patente>datos)
    {
      StreamReader reader = null;
      Patente aux=null;
      Queue<Patente> patentes = null;
      try
      {
        reader = new StreamReader(archivo);
        while(reader.EndOfStream)
        {
          aux.CodigoPatente = reader.ReadLine();
          patentes.Enqueue(aux);
            

        }


      }

      catch (Exception a)
      {

        throw a;
      }
      finally
      {
        reader.Close();
        
      }
      datos = patentes;
    }

    }
}
