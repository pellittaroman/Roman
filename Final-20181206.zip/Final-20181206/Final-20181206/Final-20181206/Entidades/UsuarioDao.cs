﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Entidades
{
    public class UsuarioDao
    {
        static SqlCommand command;
        static SqlConnection connection;
        static string conexion = "Data Source=.\\SQLEXPRESS; Initial Catalog=final-20181206; Integrated Security=true";

        static UsuarioDao()
        {
            connection = new SqlConnection(conexion);
            command = new SqlCommand();
            command.CommandType = System.Data.CommandType.Text;
            command.Connection = connection;
        }
        public bool Guardar(Usuario u)
        {
            bool ok = true;
            try
            {
                command.CommandText = "INSERT INTO Usuarios(nombre,clave) Values ('" + u.Nombre + "','" + u.Clave + "')";
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception a)
            {

                throw a;
            }
            finally
            {
                if(connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            
            return ok;
        }
        public Usuario Leer(string usuario, string clave)
        {
            Usuario aux=new Usuario("","contraseña");
            try
            {
                command.CommandText = "SELECT * FROM Usuarios WHERE nombre= '"+usuario+"' and clave= '"+clave+"'";
                connection.Open();
                SqlDataReader oDr= command.ExecuteReader();
                while(oDr.Read())
                {
                    aux = new Usuario(oDr["nombre"].ToString(), oDr["clave"].ToString());
                }

            }
            catch (Exception a)
            {

                throw a;
            }
            finally
            {
                if(connection.State==System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return aux;
        }

    }
}
