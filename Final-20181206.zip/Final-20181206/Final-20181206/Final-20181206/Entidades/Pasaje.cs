﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Entidades
{
    public abstract class Pasaje
    {
        //[XmlInclude (typeof(PasajeAvion))]
        //[XmlInclude (typeof(PasajeMicro))]
        private Pasajero pasajero;
        private string origen;
        private string destino;
        private float precio;
        private DateTime fecha;

        public Pasajero Pasajero { get => pasajero; set => pasajero = value; }
        public string Origen { get => origen; set => origen = value; }
        public string Destino { get => destino; set => destino = value;}
        public float Precio { get => precio; set => precio = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }
        public Pasaje(string origen, string destino, Pasajero pasajero, float precio, DateTime fecha)
        {
            this.origen = origen;
            this.destino = destino;
            this.pasajero = pasajero;
            this.precio = precio;
            this.fecha = fecha;
        }
        public abstract float PrecioFinal { get; set; }
      
        public Pasaje()
        {

        }
        public static  bool operator ==(Pasaje a, Pasaje b)
            {
                return  (a.origen == b.origen && a.destino==b.destino&& a.pasajero.Dni==b.pasajero.Dni && a.fecha==b.fecha) ;
            }
        public static bool operator !=(Pasaje a, Pasaje b)
        {
            return !(a == b);
        }
        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Origen: {0}\n", this.Origen);
            sb.AppendFormat("Destino: {0}\n", this.Destino);
            sb.AppendFormat("Pasajero:{0}\n", this.Pasajero.ToString());
            sb.AppendFormat("Precio:{0}\n", this.Precio);
            sb.AppendFormat("Fecha: {0}\n", this.fecha);
            return sb.ToString();
        }

    }
}
