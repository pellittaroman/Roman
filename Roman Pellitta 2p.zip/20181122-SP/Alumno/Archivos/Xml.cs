using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using System.Xml;

namespace Archivos
{
    public class Xml<T>:IArchivo<T>
    {

      public void Guardar(string archivo,T datos)
    {
      XmlSerializer xml=new XmlSerializer(typeof(T));
      XmlTextWriter writer=null;
      try
      {
        writer = new XmlTextWriter(archivo, null);
        xml.Serialize(writer, datos);

      }
      catch (Exception a)
      {

        throw a;
      }
      finally
      {
        writer.Close();
      }
    } 
    public void Leer(string archivo, out T datos)
    {
      XmlSerializer xml = new XmlSerializer(typeof(T));
      XmlTextReader reader = null;
      T aux;
      try
      {
        reader = new XmlTextReader(archivo);
        aux=(T)xml.Deserialize(reader);
      }
      catch (Exception a)
      {

        throw a;
      }
      finally
      {
        reader.Close();
      }
      

      
        datos = aux;
      
    }
    }
}
