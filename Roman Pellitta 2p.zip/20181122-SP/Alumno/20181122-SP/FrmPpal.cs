using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Entidades;
using Archivos;
using System.Threading;

namespace _20181122_SP
{
    public partial class FrmPpal : Form
    {
        Queue<Patente> cola;
    List<Thread> threads;
    
        public FrmPpal()
        {
            InitializeComponent();

            this.cola = new Queue<Patente>();
            this.threads = new List<Thread>();
        }

        private void FrmPpal_Load(object sender, EventArgs e)
        {
      VistaPatentes += vistaPatente1;
          VistaPatentes += vistaPatente2;
        }

        private void FrmPpal_FormClosing(object sender, FormClosingEventArgs e)
        {
      FinalizarSimulacion();
       
        }

        private void btnXml_Click(object sender, EventArgs e)
        {
      Xml<Queue<Patente>> patentes = new Xml<Queue<Patente>>();
      Queue<Patente> patente;
      patentes.Leer("patentes.xml", out patente);
        }

        private void btnTxt_Click(object sender, EventArgs e)
        {
      Texto text = new Texto();
      Queue<Patente> patentes;
      text.Leer("patentes.txt", out patentes);

        }

        private void btnSql_Click(object sender, EventArgs e)
        {

        }

        private void FinalizarSimulacion()
        {
      foreach (Thread aux in threads)
      {
        if (aux.IsAlive)
        {
          aux.Abort();
        }
      }

    }
    public void ProximaPatente()
    {
      Thread t = new Thread(MostrarPatente);
      Patente aux;
      while(cola.Count!=0)
      {
        aux = (Patente)cola.Dequeue();
        t.Start(aux);
        threads.Add(t);
      }
     

    }

    
    }
}
