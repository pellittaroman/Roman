using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Archivos;

namespace UnitTestProject
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    public void TestMethod1()
    {
      Texto text = new Texto();
      try
      {
        text.Guardar("", null);
      }
      catch (Exception a )
      {
        Assert.IsInstanceOfType(a, typeof(NullReferenceException));
        throw;
      }
    }
  }
}
