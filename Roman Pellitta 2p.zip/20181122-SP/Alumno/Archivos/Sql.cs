using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using Entidades;

namespace Archivos
{
  public class Sql : IArchivo<Queue<Patente>>
  {
    private  static SqlCommand comando;
    private  static SqlConnection conexion;
    public  Sql()
      {
      conexion = new SqlConnection("Data Source=.\\SqlExpress,Initial Catalog=patentes-sp-2018,Integrated Secury=True");
      comando = new SqlCommand();
      comando.CommandType = CommandType.Text;
      comando.Connection = conexion;
      }
      public void Guardar(string tabla,Queue<Patente> datos)
    {
      comando.CommandText = "INSERT INTO dbo.patentes(patentes,tipo,alumno) VALUES (string.Format({0},{1},Roman Pellitta)";
      conexion.Open();
      comando.ExecuteNonQuery();
        
    }
    public void Leer(string tabla,out Queue<Patente> datos)
    {
      datos = new Queue<Patente>();
    }
        
    }
}
