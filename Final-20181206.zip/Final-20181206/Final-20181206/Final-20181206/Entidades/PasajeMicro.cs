﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PasajeMicro:Pasaje
    {
        
        private Servicio tipoServicio;
        public Servicio TipoServico { get => tipoServicio; set => tipoServicio = value; }
        public PasajeMicro()
        {

        }
        public PasajeMicro(string origen,string destino,Pasajero pasajero,float precio,DateTime fecha,Servicio servicio)
            :base(origen,destino,pasajero,precio,fecha)
        {
            this.TipoServico = servicio;
        }
        public override float PrecioFinal
        {
            get
            {
                float precioFinal = Precio;
                if(tipoServicio==Servicio.SemiCama)
                {
                    precioFinal = precioFinal * 0.1f;
                    precioFinal = Precio + precioFinal;
                }
                else if(tipoServicio==Servicio.Ejecutivo)
                {
                    precioFinal = precioFinal * 0.2f;
                    precioFinal = Precio + precioFinal;
                }
                return precioFinal;
            }
            set
            {
                this.Precio = value;
            }
        }
        public override string Mostrar()
        {

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendFormat("Tipo de Servicio: {0}\n", this.TipoServico);
            sb.AppendFormat("Precio Total:{0}\n", this.PrecioFinal);
            return sb.ToString();

        }
    }
}
