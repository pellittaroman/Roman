using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace Entidades
{
  public class Dao<T>:IArchivos<T>
  {

    public T Leer(string RutaDeArchivo)
    {

    }
    public bool Guardar(string RutaDeArchivo,T datos)
    {
      SqlCommand comando;

      comando = new SqlCommand();


    }
  }
}
