﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void DelegadoMensaje(string mensaje);
    public class Agencia
    {
        public string nombre;
        public List<Pasaje> pasajesVendidos;
        public event DelegadoMensaje Informar;
        private Agencia()
        {
            pasajesVendidos = new List<Pasaje>();
        }
        public Agencia(string nombre)
            :this()
        {
            this.nombre = nombre;
        }
        public float CalcularGanancia()
        {
            float contador=0;
            foreach(Pasaje a in this.pasajesVendidos)
            {
                contador += a.PrecioFinal;
            }
            return contador;
        }
        public static bool operator ==(Agencia a,Pasaje p)
        {
            bool ok = false;
            foreach(Pasaje aux in a.pasajesVendidos)
            {
                if(aux==p)
                {
                    ok = true;
                    break;
                }
            }
            return ok;
        }
        public static bool operator !=(Agencia a, Pasaje p)
        {
            return !(a == p);
        }
        public static Agencia operator +(Agencia a, Pasaje p)
        {
            if(!(a==p))
            {
                a.pasajesVendidos.Add(p);
                a.Informar("Pasaje emitido correctamente");
            }
            else
            {
                a.Informar("Pasaje ya fue emitido con anterioridad");
            }
            return a;
        }
        public static  explicit  operator string(Agencia a)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Nombre: {0}\n", a.nombre);
            foreach(Pasaje b in a.pasajesVendidos)
            {
                sb.AppendLine(b.Mostrar());
            }
            sb.AppendFormat("Ganancia: {0}", a.CalcularGanancia());
            return sb.ToString();
        }
    }
}
